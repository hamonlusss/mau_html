function doi(x) {
    document.getElementById("hinhchinh").setAttribute("src", x.src);
}


